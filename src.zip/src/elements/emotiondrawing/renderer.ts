import type { EmotionDrawingElement } from './types';
import type { ExpressiveTone } from './types';

// ─── Constantes de diseño ────────────────────────────────────────────────────

const CARD = {
  width: 240,
  height: 118,
  radius: 12,
  padding: 12,
  border: 'rgba(15,23,42,0.13)',
  bg: 'rgba(255,255,255,0.97)',
} as const;

const SELECTION_DASH: [number, number] = [6, 5];
const SELECTION_COLOR = 'rgba(99, 102, 241, 0.55)';

// ─── Paleta por tono ─────────────────────────────────────────────────────────

interface ToneStyle {
  emoji: string;
  label: string;
  accentColor: string;
  textColor: string;
}

const TONE_STYLES: Record<ExpressiveTone, ToneStyle> = {
  alegre:    { emoji: '😄', label: 'Alegre',    accentColor: '#fef08a', textColor: '#713f12' },
  tranquilo: { emoji: '😌', label: 'Tranquilo', accentColor: '#bbf7d0', textColor: '#14532d' },
  triste:    { emoji: '😢', label: 'Triste',    accentColor: '#bfdbfe', textColor: '#1e3a5f' },
  tenso:     { emoji: '😤', label: 'Tenso',     accentColor: '#fecaca', textColor: '#7f1d1d' },
  caotico:   { emoji: '🌀', label: 'Caótico',   accentColor: '#e9d5ff', textColor: '#4c1d95' },
  neutro:    { emoji: '😐', label: 'Neutro',    accentColor: '#f1f5f9', textColor: '#334155' },
};

// ─── Utilidades ──────────────────────────────────────────────────────────────

type BoundingBox = {
  left: number;
  top: number;
  right: number;
  bottom: number;
};

function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value));
}

export function getBounds(element: EmotionDrawingElement): BoundingBox | null {
  const points = element.sourceStrokes.flatMap(
    (stroke) => stroke.inputs?.inputs?.map((p) => ({ x: p.x, y: p.y })) ?? []
  );

  if (points.length === 0) return null;

  let left = points[0].x;
  let top = points[0].y;
  let right = points[0].x;
  let bottom = points[0].y;

  for (const p of points) {
    if (p.x < left) left = p.x;
    if (p.y < top) top = p.y;
    if (p.x > right) right = p.x;
    if (p.y > bottom) bottom = p.y;
  }

  return { left, top, right, bottom };
}

/** Dibuja texto truncado con ellipsis si excede maxWidth. */
function fillTextEllipsis(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number
): void {
  if (ctx.measureText(text).width <= maxWidth) {
    ctx.fillText(text, x, y);
    return;
  }

  let truncated = text;
  while (truncated.length > 0 && ctx.measureText(truncated + '…').width > maxWidth) {
    truncated = truncated.slice(0, -1);
  }

  ctx.fillText(truncated + '…', x, y);
}

/**
 * Dibuja una fila de métrica con:
 * etiqueta | barra | porcentaje
 *
 * totalWidth incluye TODO el ancho disponible dentro de la tarjeta.
 */
function drawBar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  totalWidth: number,
  label: string,
  value: number,
  color: string
): void {
  const safeValue = clamp(value, 0, 1);

  const labelW = 74;
  const percentW = 32;
  const gap = 8;
  const barH = 7;

  const barX = x + labelW + gap;
  const percentX = x + totalWidth;
  const barWidth = Math.max(
    24,
    totalWidth - labelW - percentW - gap * 2
  );

  ctx.save();
  ctx.textBaseline = 'middle';

  // Etiqueta
  ctx.fillStyle = '#475569';
  ctx.font = '10px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(label, x, y + barH / 2);

  // Fondo barra
  ctx.fillStyle = '#e2e8f0';
  ctx.beginPath();
  ctx.roundRect(barX, y, barWidth, barH, 999);
  ctx.fill();

  // Relleno barra
  const fill = safeValue <= 0 ? 0 : Math.max(3, safeValue * barWidth);
  if (fill > 0) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.roundRect(barX, y, fill, barH, 999);
    ctx.fill();
  }

  // Porcentaje
  ctx.fillStyle = '#94a3b8';
  ctx.font = '9px sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText(`${Math.round(safeValue * 100)}%`, percentX, y + barH / 2);

  ctx.restore();
}

// ─── Render principal ────────────────────────────────────────────────────────

export function render(
  ctx: CanvasRenderingContext2D,
  element: EmotionDrawingElement
): void {
  const bounds = getBounds(element);
  if (!bounds) return;

  const { analysis } = element;
  const toneStyle = TONE_STYLES[analysis.expressiveTone] ?? TONE_STYLES.neutro;

  const drawingW = bounds.right - bounds.left;
  const drawingH = bounds.bottom - bounds.top;

  // Posición base: centrada sobre el dibujo
  const rawCardX = bounds.left + drawingW / 2 - CARD.width / 2;
  const rawCardY = bounds.top - CARD.height - 14;

  // Clamp para que no se salga del canvas
  const canvasW = ctx.canvas.width;
  const canvasH = ctx.canvas.height;
  const cardX = clamp(rawCardX, 8, Math.max(8, canvasW - CARD.width - 8));
  const cardY = clamp(rawCardY, 8, Math.max(8, canvasH - CARD.height - 8));

  ctx.save();

  // ── 1. Borde de selección alrededor del dibujo ──────────────────────────
  ctx.strokeStyle = SELECTION_COLOR;
  ctx.lineWidth = 1.5;
  ctx.setLineDash(SELECTION_DASH);
  ctx.strokeRect(
    bounds.left - 8,
    bounds.top - 8,
    Math.max(16, drawingW + 16),
    Math.max(16, drawingH + 16)
  );
  ctx.setLineDash([]);

  // ── 2. Sombra de la tarjeta ──────────────────────────────────────────────
  ctx.shadowColor = 'rgba(0, 0, 0, 0.10)';
  ctx.shadowBlur = 10;
  ctx.shadowOffsetY = 3;

  // ── 3. Fondo de la tarjeta ───────────────────────────────────────────────
  ctx.fillStyle = CARD.bg;
  ctx.strokeStyle = CARD.border;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.roundRect(cardX, cardY, CARD.width, CARD.height, CARD.radius);
  ctx.fill();
  ctx.stroke();

  ctx.shadowColor = 'transparent';
  ctx.shadowBlur = 0;
  ctx.shadowOffsetY = 0;

  const px = cardX + CARD.padding;
  const innerW = CARD.width - CARD.padding * 2;

  // ── 4. Chip de tono ──────────────────────────────────────────────────────
  const chipText = `${toneStyle.emoji} ${toneStyle.label}`;
  const chipFont = '600 11px sans-serif';
  ctx.font = chipFont;

  const chipTextW = ctx.measureText(chipText).width;
  const chipPadX = 8;
  const chipH = 18;
  const chipW = chipTextW + chipPadX * 2;
  const chipY = cardY + CARD.padding;

  ctx.fillStyle = toneStyle.accentColor;
  ctx.beginPath();
  ctx.roundRect(px, chipY, chipW, chipH, chipH / 2);
  ctx.fill();

  ctx.save();
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'left';
  ctx.fillStyle = toneStyle.textColor;
  ctx.font = chipFont;
  ctx.fillText(chipText, px + chipPadX, chipY + chipH / 2);
  ctx.restore();

  // Confianza a la derecha del chip
  const confPct = Math.round(clamp(analysis.confidence, 0, 1) * 100);
  ctx.save();
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'right';
  ctx.font = '9px sans-serif';
  ctx.fillStyle = '#94a3b8';
  ctx.fillText(`conf. ${confPct}%`, cardX + CARD.width - CARD.padding, chipY + chipH / 2);
  ctx.restore();

  // ── 5. Barras de energía y organización ─────────────────────────────────
  const barY = chipY + chipH + 12;
  drawBar(ctx, px, barY, innerW, 'Energía', analysis.energyLevel, '#f97316');
  drawBar(ctx, px, barY + 18, innerW, 'Organización', analysis.organizationLevel, '#6366f1');

  // ── 6. Texto de explicación ──────────────────────────────────────────────
  const explanation =
    analysis.explanation ||
    analysis.visualSummary ||
    'Sin descripción';

  ctx.fillStyle = '#475569';
  ctx.font = '11px sans-serif';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'alphabetic';
  fillTextEllipsis(ctx, explanation, px, cardY + CARD.height - 12, innerW);

  ctx.restore();
}